typedef struct conta Conta;


Conta *criarPilha(Conta *lista);
Conta *Inserir(Conta *lista);
Conta *Remover(Conta *lista);
int Vazio(Conta *lista);
Conta *Liberar(Conta *lista);
void Mostrartopo(Conta *lista);
void MostrartodaPilha(Conta *lista);
