char concatenar(char *str1,char *str2 );
int tamanho(char *str);
int comparar(char *str, char *str2);
void liberar(char *str);